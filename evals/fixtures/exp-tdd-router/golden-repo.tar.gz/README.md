# router

A small URL router: compile route patterns, match paths, and reverse-build URLs.

## Layout

- `router/pattern.py` — `compile_pattern(pattern)` and `match_pattern(compiled, path)`.
- `router/core.py` — the `Router` class plus `NotFound` and `BuildError` exceptions.
- `router/__init__.py` — public API re-exports.

Implement the behavior described in `spec.md`. All public functions currently
raise `NotImplementedError`.
