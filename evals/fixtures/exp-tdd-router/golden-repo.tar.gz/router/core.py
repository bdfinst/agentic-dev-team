"""Router: register named routes, match paths, and reverse-build URLs.

Implement the Router class and the two exception types per spec.md.
"""


class NotFound(Exception):
    """Raised by Router.match when no registered route matches the path."""


class BuildError(Exception):
    """Raised by Router.reverse on missing or extra params."""


class Router:
    """A URL router. See spec.md for precedence and method contracts."""

    def __init__(self):
        raise NotImplementedError

    def add(self, name, pattern, handler=None):
        """Register a named route."""
        raise NotImplementedError

    def match(self, path):
        """Return (name, params, handler) for the best matching route.

        Raise NotFound if nothing matches.
        """
        raise NotImplementedError

    def reverse(self, name, **params):
        """Rebuild the URL path for a named route from params.

        Raise BuildError on missing or extra params.
        """
        raise NotImplementedError
