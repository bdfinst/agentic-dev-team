"""router: a small URL router with patterns, matching, and reverse URL building.

Public API:
    pattern.compile_pattern(pattern) -> compiled
    pattern.match_pattern(compiled, path) -> dict | None
    core.Router          (add / match / reverse)
    core.NotFound        (raised by Router.match on no match)
    core.BuildError      (raised by Router.reverse on bad params)
"""

from .pattern import compile_pattern, match_pattern
from .core import Router, NotFound, BuildError

__all__ = [
    "compile_pattern",
    "match_pattern",
    "Router",
    "NotFound",
    "BuildError",
]
