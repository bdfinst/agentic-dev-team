"""Route pattern compilation and matching.

Implement the functions below per spec.md.
"""


def compile_pattern(pattern):
    """Compile a route pattern string into an opaque compiled object.

    See spec.md for the pattern syntax (static segments, {name}, {name:int},
    {name:*} wildcard).
    """
    raise NotImplementedError


def match_pattern(compiled, path):
    """Match a path against a compiled pattern.

    Return a dict of captured params on success, or None on no match.
    """
    raise NotImplementedError
