# tmpl — a tiny Mustache-like template engine

Implement the engine described in `spec.md`. The public API lives in the
`tmpl` package:

```python
from tmpl import render, TemplateError
```

- `tmpl/parser.py` — turns a template string into a list of nodes; exports
  `parse` and `TemplateError`.
- `tmpl/render.py` — walks the nodes with a context + partials; exports `render`.

The stubs raise `NotImplementedError`. Make `spec.md`'s scenarios pass.
