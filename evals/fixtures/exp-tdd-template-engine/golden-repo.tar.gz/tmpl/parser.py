"""Tokenize and parse a template string into a list of nodes.

A node is a tuple whose first element is a kind string. Node kinds:
    ("text", str)
    ("var", name)                 -- escaped variable {{name}}
    ("triple", name)              -- unescaped variable {{{name}}}
    ("section", name, [nodes])    -- {{#name}}...{{/name}}
    ("inverted", name, [nodes])   -- {{^name}}...{{/name}}
    ("partial", name)             -- {{>name}}

The exact node representation is an implementation detail of this package;
callers should use render() rather than depend on node shapes.
"""


class TemplateError(Exception):
    """Raised when a template has an unclosed or mismatched section."""


def parse(template):
    """Parse a template string into a list of nodes.

    Raises TemplateError on an unclosed or mismatched section.
    """
    raise NotImplementedError
