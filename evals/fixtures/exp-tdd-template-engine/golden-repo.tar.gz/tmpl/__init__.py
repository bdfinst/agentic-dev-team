"""tmpl: a small Mustache-like template engine.

Public API:
    render(template, context, partials=None) -> str
    TemplateError                  -- raised on unclosed/mismatched sections

Submodules:
    tmpl.parser  -- tokenize/parse a template string into a node list
    tmpl.render  -- walk parsed nodes with a context + partials
"""
from .parser import parse, TemplateError
from .render import render

__all__ = ["render", "parse", "TemplateError"]
