"""Render a parsed template (list of nodes) against a context + partials."""

from .parser import parse, TemplateError  # noqa: F401  (re-exported convenience)


def render(template, context, partials=None):
    """Render a template string with the given context.

    Args:
        template: the template source string.
        context:  a dict of values.
        partials: optional dict mapping partial name -> template string.

    Returns:
        The rendered string.

    Raises:
        TemplateError: if the template has an unclosed/mismatched section.
    """
    raise NotImplementedError
