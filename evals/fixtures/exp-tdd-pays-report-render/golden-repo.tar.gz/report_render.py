"""Report renderer — stub (public API surface only).

Implement ReportRenderer in this file.
"""


class ReportRenderer:
    """Renders tabular data into registered output formats.

    Usage::

        renderer = ReportRenderer()
        renderer.register_format("csv", my_csv_handler)
        output = renderer.render(data, "csv", delimiter=",")
        for chunk in renderer.render_stream(data, "csv"):
            ...

    Format handlers are callables: ``(data: list[dict], **options) -> str``
    """

    def register_format(self, name, handler):
        """Register a format handler under *name*.

        Re-registering replaces the existing handler.

        Args:
            name: format identifier string (e.g. "csv", "json").
            handler: callable(data, **options) -> str.
        """
        raise NotImplementedError

    def render(self, data, format_name, **options):
        """Render *data* using the named format handler.

        Args:
            data: list of row dicts. Keys are column names.
            format_name: registered format name.
            **options: forwarded to the handler.

        Returns:
            str: the handler's return value.

        Raises:
            ValueError: if *format_name* is not registered.
        """
        raise NotImplementedError

    def available_formats(self):
        """Return a list of all registered format names."""
        raise NotImplementedError
