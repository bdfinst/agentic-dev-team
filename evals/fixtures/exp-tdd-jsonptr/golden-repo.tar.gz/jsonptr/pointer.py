"""JSON Pointer parsing and resolution (RFC 6901)."""


class PointerError(Exception):
    """Raised when a pointer string is syntactically invalid."""


class ResolveError(Exception):
    """Raised when a valid pointer does not address a value in the document."""


def parse(pointer):
    """Parse a JSON Pointer string into a list of reference tokens.

    "" -> []; "/foo/0/bar" -> ["foo", "0", "bar"]. Decodes ~1 -> / and ~0 -> ~.
    A non-empty pointer not starting with "/" raises PointerError.
    """
    raise NotImplementedError


def resolve(doc, pointer):
    """Return the value addressed by `pointer` within `doc`.

    "" returns the whole doc. Missing object key or out-of-range / non-decimal
    array index raises ResolveError.
    """
    raise NotImplementedError
