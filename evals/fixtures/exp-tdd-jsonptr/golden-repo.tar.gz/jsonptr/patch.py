"""JSON Patch application (subset of RFC 6902)."""


class PatchError(Exception):
    """Raised for an unknown op or an op that cannot be applied."""


def apply_patch(doc, ops):
    """Apply a list of patch ops to `doc`, returning a NEW document.

    Must not mutate the input. Supports ops: add, remove, replace. Unknown op
    raises PatchError. remove/replace on a missing path raises PatchError.
    """
    raise NotImplementedError
