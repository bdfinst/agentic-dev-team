# jsonptr

A small JSON Pointer (RFC 6901) + JSON Patch (subset of RFC 6902) library.

Implement the feature described in `spec.md`. The public API is re-exported from
the `jsonptr` package (`import jsonptr`). All functions are currently stubs that
raise `NotImplementedError`.
