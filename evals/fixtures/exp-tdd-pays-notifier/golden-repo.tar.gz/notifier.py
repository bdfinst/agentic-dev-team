"""Notification service — stub (public API surface only).

Implement NotificationService in this file.
"""


class NotificationService:
    """Dispatches notifications to recipients through registered channel handlers.

    Usage::

        svc = NotificationService()
        svc.register_channel("email", email_handler)
        result = svc.send("alice@example.com", "Your order shipped")
        results = svc.send_bulk(["alice", "bob"], "Sale starts now!")

    Channel handlers are callables: ``(recipient: str, message: str) -> bool``
    returning True on success and False on failure.
    """

    def register_channel(self, name, handler, priority=0):
        """Register a delivery channel.

        Args:
            name: unique channel identifier (e.g. "email", "sms").
            handler: callable(recipient, message) -> bool.
            priority: int, default 0. Higher priority channels are attempted first.
        """
        raise NotImplementedError

    def send(self, recipient, message, channels=None):
        """Send a message to one recipient.

        Args:
            recipient: target identifier (e.g. email address, phone number).
            message: text to deliver.
            channels: list of channel names to use, or None for all registered channels.

        Returns:
            dict[str, bool] mapping channel name to delivery success.

        Raises:
            ValueError: if a channel name in *channels* is not registered.
        """
        raise NotImplementedError

    def send_bulk(self, recipients, message, channels=None):
        """Send a message to multiple recipients.

        Args:
            recipients: list of target identifiers.
            message: text to deliver.
            channels: optional list of channel names (same semantics as send()).

        Returns:
            dict[str, dict[str, bool]] mapping each recipient to their result dict.
        """
        raise NotImplementedError
