"""String Calculator kata — starting state.

The orchestrator must implement `add` per spec.md so test_string_calc.py passes.
"""


def add(numbers: str) -> int:
    raise NotImplementedError("implement add() per spec.md")
