"""Acceptance tests for the String Calculator. Run: python3 test_string_calc.py
Exits 0 only when every case passes."""
from string_calc import add


def main() -> int:
    cases = [
        ("", 0),
        ("1", 1),
        ("1,2", 3),
        ("1,2,3,4", 10),
        ("1\n2,3", 6),
    ]
    failures = []
    for arg, want in cases:
        try:
            got = add(arg)
        except Exception as exc:  # noqa: BLE001
            failures.append(f"add({arg!r}) raised {exc!r}")
            continue
        if got != want:
            failures.append(f"add({arg!r}) == {got!r}, want {want!r}")
    if failures:
        for f in failures:
            print("FAIL:", f)
        return 1
    print("OK: all string-calculator cases pass")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
