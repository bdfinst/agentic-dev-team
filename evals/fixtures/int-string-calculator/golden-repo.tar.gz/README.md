# String Calculator (integration eval golden repo)

Starting-state snapshot for the dev-team integration eval tier (#313). The
orchestrator implements `add` in `string_calc.py` per `spec.md`; the acceptance
test `test_string_calc.py` must then exit 0.
