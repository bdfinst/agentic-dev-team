# ledger

A small double-entry bookkeeping ledger. All monetary amounts are **integer cents**
(no floats). In a posting, a positive amount is a **debit** and a negative amount is
a **credit**; every posting must balance (entry amounts sum to zero).

## Public API

```python
import ledger

lg = ledger.Ledger()
lg.open_account("cash", "asset")
lg.open_account("sales", "income")
lg.post("2026-01-01", "sale", [("cash", 1000), ("sales", -1000)])
lg.balance("cash")            # -> 1000

ledger.trial_balance(lg)      # -> [("cash", 1000), ("sales", -1000)]
ledger.total_debits(lg)       # -> 1000
ledger.total_credits(lg)      # -> 1000
ledger.account_statement(lg, "cash")  # -> [("2026-01-01", "sale", 1000)]
```

Errors: `ledger.LedgerError` (duplicate/unknown account, bad type),
`ledger.UnbalancedError` (posting does not sum to zero).

See `spec.md` for the full specification. The shipped package contains stubs only;
implement the spec to make the acceptance tests pass.
