"""Reporting over a Ledger: trial balance, totals, and account statements."""


def trial_balance(ledger):
    """Return a list of (name, balance_cents) for every account that has at
    least one posting, sorted by account name.
    """
    raise NotImplementedError


def total_debits(ledger):
    """Return the total of all debit (positive) amounts across all postings,
    as a positive integer-cents value.
    """
    raise NotImplementedError


def total_credits(ledger):
    """Return the total of all credit (negative) amounts across all postings,
    as a positive integer-cents value (the sum of -amount for negative entries).
    """
    raise NotImplementedError


def account_statement(ledger, name):
    """Return a list of (date, description, amount_cents) for postings that
    touch `name`, in posting order. Raises LedgerError if the account is unknown.
    """
    raise NotImplementedError
