"""Accounts and double-entry postings.

All amounts are integer cents. In a posting's entries, a positive amount is a
debit and a negative amount is a credit. Each posting must balance: the entry
amounts must sum to zero.
"""

ACCOUNT_TYPES = ("asset", "liability", "equity", "income", "expense")


class LedgerError(Exception):
    """Raised for invalid ledger operations (duplicate or unknown account, bad type)."""


class UnbalancedError(Exception):
    """Raised when a posting's entry amounts do not sum to zero."""


class Ledger:
    """A double-entry ledger of accounts and postings."""

    def open_account(self, name, type):
        """Open an account `name` of `type` (one of ACCOUNT_TYPES).

        Raises LedgerError if `name` already exists or `type` is invalid.
        """
        raise NotImplementedError

    def post(self, date, description, entries):
        """Record a posting.

        `entries` is a list of (account_name, amount_cents) tuples. Positive
        amounts are debits, negative are credits. Raises UnbalancedError if the
        amounts do not sum to zero, LedgerError if any account is unknown.
        """
        raise NotImplementedError

    def balance(self, account_name):
        """Return the signed integer-cents balance of `account_name`.

        Raises LedgerError if the account is unknown.
        """
        raise NotImplementedError
