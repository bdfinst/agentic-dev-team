from feature import total
assert total([]) == 0
print("change ok")
