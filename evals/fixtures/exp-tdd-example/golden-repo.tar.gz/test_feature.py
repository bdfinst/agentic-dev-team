from feature import total
assert total([1, 2, 3]) == 6
print("stage1 ok")
