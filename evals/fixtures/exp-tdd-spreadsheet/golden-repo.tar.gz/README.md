# mini-spreadsheet (stub)

This is a stub package. Implement the feature described in `spec.md`: a tiny
in-memory spreadsheet with cells, recursive formula evaluation, range functions,
cycle detection, and division-by-zero handling. The public API is re-exported
from `sheet/__init__.py`; every public function currently raises
`NotImplementedError` until you implement it per `spec.md`.
