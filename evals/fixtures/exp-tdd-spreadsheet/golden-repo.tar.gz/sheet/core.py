"""Sheet model, evaluation, range expansion, and cycle detection.

Implement per spec.md.
"""


class CycleError(Exception):
    """Raised when a formula transitively references its own cell."""


class Sheet:
    """An in-memory spreadsheet of cells addressed like 'A1', 'B2'.

    Implement per spec.md.
    """

    def __init__(self):
        """Implement per spec.md."""
        raise NotImplementedError

    def set_cell(self, addr, value):
        """Set a cell to a literal number or a formula string. Implement per spec.md."""
        raise NotImplementedError

    def get_raw(self, addr):
        """Return what was set for a cell (unevaluated). Implement per spec.md."""
        raise NotImplementedError

    def get_value(self, addr):
        """Return the evaluated numeric value of a cell. Implement per spec.md."""
        raise NotImplementedError
