"""Formula tokenizing and parsing. Implement per spec.md."""


def tokenize(formula):
    """Tokenize a formula body (the text after the leading '=').

    Implement per spec.md.
    """
    raise NotImplementedError


def parse(formula):
    """Parse a formula body into an AST consumed by core evaluation.

    Implement per spec.md.
    """
    raise NotImplementedError
