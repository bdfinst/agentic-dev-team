"""Pricing engine — stub (public API surface only).

Implement PricingEngine and Discount in this file.
"""


class Discount:
    """A discount to apply to a cart.

    Args:
        discount_type: "percent" (reduce by a percentage) or "fixed" (reduce by a
            fixed amount).
        value: the discount amount (non-negative number).
        priority: int, default 0.  Higher values apply before lower values.
        group: str or None.  Discounts sharing a group string are mutually
            exclusive — only one applies per group.
    """

    def __init__(self, discount_type, value, priority=0, group=None):
        raise NotImplementedError


class PricingEngine:
    """Applies a configurable stack of discounts to a shopping cart.

    Usage::

        engine = PricingEngine()
        engine.add_discount(Discount("percent", 10))
        total = engine.calculate([{"price": 50.0, "qty": 2}])
    """

    def __init__(self):
        raise NotImplementedError

    def add_discount(self, discount):
        """Register a discount on this engine."""
        raise NotImplementedError

    def calculate(self, items):
        """Return the discounted cart total.

        Args:
            items: list of dicts, each with:
                "price" (float) — unit price
                "qty" (int, optional, default 1) — quantity
                "category" (str, optional) — product category label

        Returns:
            float: discounted total, rounded to 2 decimal places, minimum 0.0.
        """
        raise NotImplementedError
