# scheduler

A task scheduler that resolves execution order from declared dependencies.

- `scheduler.Graph` — build the dependency graph (`add_task`, `add_dependency`,
  `tasks`, `dependencies`).
- `scheduler.topological_order(graph)` — deterministic execution order
  (alphabetical tie-break); raises `CycleError` on a cycle.
- `scheduler.detect_cycle(graph)` — one cycle as a list, or `None`.
- `scheduler.ready_tasks(graph, done)` — tasks runnable given a done-set.

Implement the bodies in `scheduler/`. See `spec.md` for exact behavior.
