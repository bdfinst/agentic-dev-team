"""Topological ordering, ready-task selection, and cycle detection."""


class CycleError(Exception):
    """Raised when a topological order is requested on a cyclic graph."""


def topological_order(graph):
    """Return a deterministic topological ordering of all tasks.

    Ties are broken alphabetically. Raises :class:`CycleError` if the
    graph contains a cycle.
    """
    raise NotImplementedError


def detect_cycle(graph):
    """Return one cycle as a list of task names, or ``None`` if acyclic."""
    raise NotImplementedError


def ready_tasks(graph, done):
    """Return tasks whose dependencies are all in ``done``, alphabetically.

    Tasks already in ``done`` are excluded.
    """
    raise NotImplementedError
