"""Dependency graph for tasks."""


class Graph:
    """A directed graph of tasks and their dependencies.

    A dependency ``add_dependency(task, depends_on)`` means ``task`` runs
    AFTER ``depends_on`` (edge depends_on -> task).
    """

    def add_task(self, name):
        """Register a task by name. Idempotent."""
        raise NotImplementedError

    def add_dependency(self, task, depends_on):
        """Declare that ``task`` depends on ``depends_on``.

        Auto-creates either task if not already present.
        """
        raise NotImplementedError

    def tasks(self):
        """Return the task names as a sorted list."""
        raise NotImplementedError

    def dependencies(self, task):
        """Return the direct dependencies of ``task`` as a sorted list."""
        raise NotImplementedError
