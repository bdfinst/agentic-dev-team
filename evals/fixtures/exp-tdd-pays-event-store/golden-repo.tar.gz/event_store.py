"""Event store — stub (public API surface only).

Implement EventStore and OptimisticConcurrencyError in this file.
"""


class OptimisticConcurrencyError(Exception):
    """Raised when an append() call fails an expected_version check."""


class EventStore:
    """Append-only, per-stream event store with projection support.

    Usage::

        store = EventStore()
        event = store.append("orders", "OrderPlaced", {"item": "book"})
        events = store.load("orders")
        state = store.project("orders", lambda acc, e: acc + [e["event_type"]], initial_state=[])
    """

    def append(self, stream_id, event_type, data, expected_version=None):
        """Append an event to a stream.

        Args:
            stream_id: stream identifier string.
            event_type: event type label string.
            data: dict of event payload; stored verbatim.
            expected_version: int or None. If int, the stream's current version
                (number of events already stored) must equal this value or
                OptimisticConcurrencyError is raised.

        Returns:
            The stored event dict with keys: stream_id, event_type, data, version.

        Raises:
            OptimisticConcurrencyError: on version mismatch.
        """
        raise NotImplementedError

    def load(self, stream_id, from_version=0):
        """Load events from a stream.

        Args:
            stream_id: stream identifier string.
            from_version: only return events with version > from_version (default 0).

        Returns:
            list of event dicts in version order; [] if the stream does not exist.
        """
        raise NotImplementedError

    def project(self, stream_id, projection_fn, initial_state=None):
        """Reduce a stream's events into application state.

        Args:
            stream_id: stream identifier string.
            projection_fn: callable(state, event) -> state.
            initial_state: starting accumulator value (default None).

        Returns:
            Final reduced state, or initial_state if the stream does not exist.
        """
        raise NotImplementedError
